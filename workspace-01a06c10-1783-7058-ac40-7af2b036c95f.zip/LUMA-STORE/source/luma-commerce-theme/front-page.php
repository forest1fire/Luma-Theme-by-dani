<?php
/**
 * Front page fallback. The complete layout can be replaced with Elementor Pro.
 *
 * @package LumaCommerce
 */
get_header();

$elementor_editing = 'builder' === get_post_meta( get_queried_object_id(), '_elementor_edit_mode', true );
$has_content      = trim( (string) get_post_field( 'post_content', get_queried_object_id() ) );
?>
<main id="primary" class="luma-main luma-home">
<?php if ( $elementor_editing || $has_content ) : ?>
    <?php while ( have_posts() ) : the_post(); the_content(); endwhile; ?>
<?php else : ?>
    <section class="luma-home-hero">
        <div class="luma-home-hero__copy">
            <p class="luma-kicker">Autumn / winter 2026</p>
            <h1>Make<br><em>room</em><br>for more.</h1>
            <p class="luma-home-hero__intro">A sharper edit of everyday pieces, designed to move with you from first light to last call.</p>
            <a class="luma-button" href="<?php echo esc_url( luma_commerce_shop_url() ); ?>">Explore the edit <span>↗</span></a>
        </div>
        <div class="luma-home-hero__visual"><img src="<?php echo esc_url( luma_commerce_asset( 'images/luma-hero.jpg' ) ); ?>" alt="Luma autumn winter campaign" width="1584" height="672" loading="eager" fetchpriority="high" decoding="async"><span class="luma-home-hero__stamp">Built for<br>everyday<br>motion</span></div>
    </section>

    <section class="luma-home-section luma-home-categories"><div class="luma-container">
        <div class="luma-section-heading"><h2>Shop by mood</h2><a class="luma-text-link" href="<?php echo esc_url( luma_commerce_shop_url() ); ?>">View all <span>↗</span></a></div>
        <div class="luma-category-grid">
            <a class="luma-category-card" style="--luma-category-image:url('<?php echo esc_url( luma_commerce_asset( 'images/luma-men.jpg' ) ); ?>')" href="<?php echo esc_url( luma_commerce_category_url( 'men' ) ); ?>"><span><strong>Men</strong><small>Explore the edit ↗</small></span></a>
            <a class="luma-category-card" style="--luma-category-image:url('<?php echo esc_url( luma_commerce_asset( 'images/luma-women.jpg' ) ); ?>')" href="<?php echo esc_url( luma_commerce_category_url( 'women' ) ); ?>"><span><strong>Women</strong><small>Explore the edit ↗</small></span></a>
            <a class="luma-category-card" style="--luma-category-image:url('<?php echo esc_url( luma_commerce_asset( 'images/luma-drop.jpg' ) ); ?>')" href="<?php echo esc_url( luma_commerce_category_url( 'juniors' ) ); ?>"><span><strong>Juniors</strong><small>Explore the edit ↗</small></span></a>
        </div>
    </div></section>

    <?php if ( shortcode_exists( 'luma_sale_bar' ) ) echo do_shortcode( '[luma_sale_bar]' ); ?>
    <?php if ( shortcode_exists( 'luma_coupon' ) || shortcode_exists( 'luma_countdown' ) ) : ?><div class="luma-container luma-home-conversion"><?php if ( shortcode_exists( 'luma_coupon' ) ) echo do_shortcode( '[luma_coupon]' ); if ( shortcode_exists( 'luma_countdown' ) ) echo do_shortcode( '[luma_countdown]' ); ?></div><?php endif; ?>

    <section class="luma-home-section"><div class="luma-container">
        <div class="luma-section-heading"><h2>Just in</h2><a class="luma-text-link" href="<?php echo esc_url( luma_commerce_shop_url() ); ?>">Shop all <span>↗</span></a></div>
        <div class="luma-home-products">
        <?php
        $products = function_exists( 'wc_get_products' ) ? wc_get_products( array( 'limit' => 8, 'status' => 'publish', 'orderby' => 'date', 'order' => 'DESC' ) ) : array();
        if ( $products ) : foreach ( $products as $product ) :
            $badge = $product->is_on_sale() ? 'Sale' : ( $product->get_date_created() && $product->get_date_created()->getTimestamp() > strtotime( '-30 days' ) ? 'New' : '' );
            ?>
            <article class="luma-home-product"><a class="luma-home-product__image" href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail' ) ); ?><?php if ( $badge ) : ?><span><?php echo esc_html( $badge ); ?></span><?php endif; ?></a><div class="luma-home-product__meta"><h3><a href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo esc_html( $product->get_name() ); ?></a></h3><div><?php echo wp_kses_post( $product->get_price_html() ); ?></div></div><div class="luma-home-product__actions"><a class="luma-home-product__view" href="<?php echo esc_url( $product->get_permalink() ); ?>">View piece <span>↗</span></a><?php if ( function_exists( 'luma_core_option' ) && luma_core_option( 'module_quick_view', true ) && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() ) : ?><button class="luma-quick-add luma-home-product__quick-add" type="button" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" aria-label="<?php echo esc_attr( sprintf( 'Quick add %s', $product->get_name() ) ); ?>">Quick add <span>+</span></button><?php else : ?><a class="luma-home-product__options" href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo $product->is_type( 'simple' ) ? esc_html__( 'View details', 'luma-commerce-theme' ) : esc_html__( 'Choose options', 'luma-commerce-theme' ); ?> <span>↗</span></a><?php endif; ?></div></article>
        <?php endforeach; else : ?>
            <div class="luma-home-empty"><p class="luma-kicker">Your first drop starts here</p><h3>Add products in WooCommerce to populate this section.</h3><a class="luma-button" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=product' ) ); ?>">Add a product <span>↗</span></a></div>
        <?php endif; ?>
        </div>
    </div></section>

    <?php if ( shortcode_exists( 'luma_trust_bar' ) ) : ?><div class="luma-container luma-home-trust"><?php echo do_shortcode( '[luma_trust_bar]' ); ?></div><?php endif; ?>

    <section class="luma-home-editorial"><div class="luma-home-editorial__copy"><p class="luma-kicker">The Luma uniform / 01</p><h2>Less<br>noise.<br>More<br>you.</h2><p>Quiet textures, confident proportions and the pieces you reach for on repeat.</p><a class="luma-button" href="<?php echo esc_url( luma_commerce_shop_url() ); ?>">Meet the uniform <span>↗</span></a></div><div class="luma-home-editorial__image"><img src="<?php echo esc_url( luma_commerce_asset( 'images/luma-drop.jpg' ) ); ?>" alt="Luma streetwear detail" width="768" height="1376" loading="lazy" decoding="async"></div></section>
<?php endif; ?>
</main>
<?php get_footer(); ?>
