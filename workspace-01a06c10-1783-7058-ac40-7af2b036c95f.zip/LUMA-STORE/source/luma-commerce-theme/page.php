<?php
get_header();
?>
<main id="primary" class="luma-main luma-page-main"><div class="luma-container luma-content-wrap">
<?php while ( have_posts() ) : the_post(); the_content(); wp_link_pages( array( 'before' => '<nav class="luma-page-links" aria-label="' . esc_attr__( 'Page sections', 'luma-commerce' ) . '"><span>' . esc_html__( 'Pages:', 'luma-commerce' ) . '</span>', 'after' => '</nav>' ) ); endwhile; ?>
</div></main>
<?php get_footer(); ?>
