<?php
get_header();
if ( ! luma_commerce_elementor_location( 'archive' ) ) :
?>
<main id="primary" class="luma-main"><div class="luma-container luma-content-wrap">
<header class="luma-archive-header"><p class="luma-kicker"><?php esc_html_e( 'The journal', 'luma-commerce' ); ?></p><?php the_archive_title( '<h1 class="luma-page-title">', '</h1>' ); ?><?php the_archive_description( '<div class="luma-archive-description">', '</div>' ); ?></header>
<?php if ( have_posts() ) : ?><div class="luma-post-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', get_post_type() ); endwhile; ?></div><?php the_posts_navigation(); else : ?><p><?php esc_html_e( 'Nothing here yet.', 'luma-commerce' ); ?></p><?php endif; ?>
</div></main>
<?php endif; get_footer(); ?>
