<?php
/**
 * Theme setup and shared helpers.
 *
 * @package LumaCommerce
 */

defined( 'ABSPATH' ) || exit;

function luma_commerce_setup() {
    load_theme_textdomain( 'luma-commerce', LUMA_COMMERCE_DIR . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'custom-logo', array(
        'height'      => 80,
        'width'       => 260,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );

    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'luma-commerce' ),
        'utility' => __( 'Utility Menu', 'luma-commerce' ),
        'footer'  => __( 'Footer Menu', 'luma-commerce' ),
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer widgets', 'luma-commerce' ),
        'id'            => 'footer-widgets',
        'description'   => __( 'Optional widgets shown above the footer legal row.', 'luma-commerce' ),
        'before_widget' => '<section id="%1$s" class="luma-footer-widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="luma-footer-widget__title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'after_setup_theme', 'luma_commerce_setup' );

function luma_commerce_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'luma_commerce_content_width', 1320 );
}
add_action( 'after_setup_theme', 'luma_commerce_content_width', 0 );

function luma_commerce_assets() {
    wp_enqueue_style( 'luma-commerce-style', get_stylesheet_uri(), array(), LUMA_COMMERCE_VERSION );
    wp_enqueue_style( 'luma-commerce-theme', LUMA_COMMERCE_URI . '/assets/css/theme.css', array( 'luma-commerce-style' ), LUMA_COMMERCE_VERSION );
    wp_enqueue_style( 'luma-commerce-seo-motion', LUMA_COMMERCE_URI . '/assets/css/seo-motion.css', array( 'luma-commerce-theme' ), LUMA_COMMERCE_VERSION );
    if ( ! get_theme_mod( 'luma_enable_animations', true ) ) wp_add_inline_style( 'luma-commerce-seo-motion', '*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important;}' );
    if ( is_rtl() ) wp_enqueue_style( 'luma-commerce-rtl', LUMA_COMMERCE_URI . '/assets/css/rtl.css', array( 'luma-commerce-theme' ), LUMA_COMMERCE_VERSION );
    $accent = sanitize_hex_color( get_theme_mod( 'luma_accent', '#f0523d' ) );
    $paper  = sanitize_hex_color( get_theme_mod( 'luma_paper', '#f5f2ec' ) );
    $heading_fonts = array( 'narrow' => '"Arial Narrow","Helvetica Neue",Arial,sans-serif', 'sans' => '"Helvetica Neue",Arial,sans-serif', 'serif' => 'Georgia,serif' );
    $body_fonts = array( 'system' => 'Inter,ui-sans-serif,system-ui,sans-serif', 'sans' => '"Helvetica Neue",Arial,sans-serif', 'serif' => 'Georgia,serif' );
    $heading_font = $heading_fonts[ get_theme_mod( 'luma_heading_font', 'narrow' ) ] ?? $heading_fonts['narrow'];
    $body_font = $body_fonts[ get_theme_mod( 'luma_body_font', 'system' ) ] ?? $body_fonts['system'];
    $container = luma_commerce_sanitize_container( get_theme_mod( 'luma_container_width', 1440 ) );
    $radius = luma_commerce_sanitize_choice( get_theme_mod( 'luma_radius', '2px' ), array( '0px' => 'Square', '2px' => 'Subtle', '6px' => 'Soft' ) );
    $scale = luma_commerce_sanitize_scale( get_theme_mod( 'luma_heading_scale', 1 ) );
    $body_size = max( 13, min( 18, absint( get_theme_mod( 'luma_body_size', 15 ) ) ) );
    $product_columns = max( 2, min( 5, absint( get_theme_mod( 'luma_product_columns', 4 ) ) ) );
    $styles = ':root{--luma-container:' . $container . 'px;--luma-product-columns:' . $product_columns . ';--luma-radius:' . $radius . ';--luma-display:' . $heading_font . ';--luma-body:' . $body_font . ';--luma-heading-scale:' . $scale . ';--luma-body-size:' . $body_size . 'px;' . ( $accent ? '--luma-accent:' . $accent . ';' : '' ) . ( $paper ? '--luma-paper:' . $paper . ';' : '' ) . '}';
    if ( ! get_theme_mod( 'luma_enable_animations', true ) ) $styles .= '*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important;}';
    wp_add_inline_style( 'luma-commerce-theme', $styles );
    wp_enqueue_script( 'luma-commerce-theme', LUMA_COMMERCE_URI . '/assets/js/theme.js', array(), LUMA_COMMERCE_VERSION, true );

    wp_localize_script( 'luma-commerce-theme', 'lumaTheme', array(
        'cartUrl' => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
        'shopUrl' => luma_commerce_shop_url(),
    ) );
}
add_action( 'wp_enqueue_scripts', 'luma_commerce_assets' );

function luma_commerce_has_seo_plugin() {
    return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'RankMath' );
}

function luma_commerce_meta_description() {
    if ( is_admin() || luma_commerce_has_seo_plugin() ) return;
    global $product;
    $description = '';
    if ( function_exists( 'is_product' ) && is_product() && $product ) $description = $product->get_short_description();
    elseif ( is_singular() && has_excerpt() ) $description = get_the_excerpt();
    elseif ( ( function_exists( 'is_shop' ) && is_shop() ) || is_post_type_archive( 'product' ) ) $description = sprintf( __( 'Explore the latest %s edit: considered pieces, easy layers and everyday essentials.', 'luma-commerce' ), luma_commerce_brand_name() );
    elseif ( is_front_page() ) $description = sprintf( __( '%s makes considered wardrobe pieces for everyday motion, with an original streetwear point of view.', 'luma-commerce' ), luma_commerce_brand_name() );
    else $description = sprintf( __( 'Discover %s: modern wardrobe pieces with a considered point of view.', 'luma-commerce' ), luma_commerce_brand_name() );
    $description = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $description ) ) );
    if ( function_exists( 'mb_substr' ) ) $description = mb_substr( $description, 0, 158 ); else $description = substr( $description, 0, 158 );
    if ( $description ) echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
}
add_action( 'wp_head', 'luma_commerce_meta_description', 2 );

function luma_commerce_social_meta() {
    if ( is_admin() || luma_commerce_has_seo_plugin() ) return;
    global $product;
    $url = is_singular() ? get_permalink() : home_url( '/' );
    $title = is_singular() ? get_the_title() : luma_commerce_brand_name();
    $description = '';
    if ( function_exists( 'is_product' ) && is_product() && $product ) $description = $product->get_short_description();
    elseif ( is_singular() && has_excerpt() ) $description = get_the_excerpt();
    else $description = sprintf( __( 'Discover %s: modern wardrobe pieces with a considered point of view.', 'luma-commerce' ), luma_commerce_brand_name() );
    $description = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $description ) ) );
    if ( function_exists( 'mb_substr' ) ) $description = mb_substr( $description, 0, 200 ); else $description = substr( $description, 0, 200 );
    $image = '';
    if ( is_singular() && has_post_thumbnail() ) $image = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
    if ( ! $image && get_theme_mod( 'custom_logo' ) ) $image = wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' );
    echo '<meta property="og:type" content="' . esc_attr( is_singular() ? 'article' : 'website' ) . '">';
    echo '<meta property="og:site_name" content="' . esc_attr( luma_commerce_brand_name() ) . '">';
    echo '<meta property="og:title" content="' . esc_attr( $title ) . '">';
    echo '<meta property="og:description" content="' . esc_attr( $description ) . '">';
    echo '<meta property="og:url" content="' . esc_url( $url ) . '">';
    echo '<meta name="twitter:card" content="summary_large_image">';
    if ( $image ) { echo '<meta property="og:image" content="' . esc_url( $image ) . '">'; echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">'; }
    echo "\n";
}
add_action( 'wp_head', 'luma_commerce_social_meta', 4 );

function luma_commerce_structured_data() {
    if ( is_admin() || luma_commerce_has_seo_plugin() ) return;
    $home = home_url( '/' ); $brand = luma_commerce_brand_name(); $graph = array( array( '@type' => 'WebSite', '@id' => $home . '#website', 'url' => $home, 'name' => $brand, 'potentialAction' => array( '@type' => 'SearchAction', 'target' => $home . '?s={search_term_string}', 'query-input' => 'required name=search_term_string' ) ) );
    $logo = get_theme_mod( 'custom_logo' ) ? wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' ) : '';
    $organization = array( '@type' => 'Organization', '@id' => $home . '#organization', 'name' => $brand, 'url' => $home );
    if ( $logo ) $organization['logo'] = array( '@type' => 'ImageObject', 'url' => $logo );
    $graph[] = $organization;
    echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ) ) . '</script>' . "\n";
}
add_action( 'wp_head', 'luma_commerce_structured_data', 3 );

function luma_commerce_preload_home_hero() {
    if ( ! is_front_page() || trim( (string) get_post_field( 'post_content', get_queried_object_id() ) ) || 'builder' === get_post_meta( get_queried_object_id(), '_elementor_edit_mode', true ) ) return;
    echo '<link rel="preload" as="image" href="' . esc_url( luma_commerce_asset( 'images/luma-hero.jpg' ) ) . '" fetchpriority="high">' . "\n";
}
add_action( 'wp_head', 'luma_commerce_preload_home_hero', 1 );

function luma_commerce_skip_link() {
    echo '<a class="luma-skip-link" href="#primary">' . esc_html__( 'Skip to content', 'luma-commerce' ) . '</a>';
}
add_action( 'wp_body_open', 'luma_commerce_skip_link', 2 );

function luma_commerce_body_classes( $classes ) {
    $classes[] = 'luma-commerce';
    if ( class_exists( 'WooCommerce' ) ) {
        $classes[] = 'luma-has-woocommerce';
    }
    if ( class_exists( 'Elementor\Plugin' ) ) {
        $classes[] = 'luma-has-elementor';
    }
    if ( 'outline' === get_theme_mod( 'luma_button_style', 'solid' ) ) $classes[] = 'luma-buttons--outline';
    if ( ! get_theme_mod( 'luma_sticky_header', true ) ) $classes[] = 'luma-header--static';
    return $classes;
}
add_filter( 'body_class', 'luma_commerce_body_classes' );

function luma_commerce_fallback_menu() {
    $departments = array( 'new-in' => __( 'New in', 'luma-commerce' ), 'men' => __( 'Men', 'luma-commerce' ), 'women' => __( 'Women', 'luma-commerce' ), 'juniors' => __( 'Juniors', 'luma-commerce' ) );
    $product_types = array( 't-shirts' => __( 'T-shirts', 'luma-commerce' ), 'outerwear' => __( 'Outerwear', 'luma-commerce' ), 'bottoms' => __( 'Bottoms', 'luma-commerce' ), 'accessories' => __( 'Accessories', 'luma-commerce' ) );
    echo '<ul id="primary-menu" class="luma-menu">';
    echo '<li class="luma-menu-mega"><a href="' . esc_url( luma_commerce_shop_url() ) . '">' . esc_html__( 'Shop', 'luma-commerce' ) . '</a><div class="luma-mega-menu"><div><small>' . esc_html__( 'Departments', 'luma-commerce' ) . '</small>';
    foreach ( $departments as $slug => $label ) echo '<a href="' . esc_url( luma_commerce_category_url( $slug ) ) . '">' . esc_html( $label ) . '</a>';
    echo '</div><div><small>' . esc_html__( 'Shop by product', 'luma-commerce' ) . '</small>';
    foreach ( $product_types as $slug => $label ) echo '<a href="' . esc_url( luma_commerce_category_url( $slug ) ) . '">' . esc_html( $label ) . '</a>';
    echo '</div><div class="luma-mega-menu__feature"><b>' . esc_html__( 'Fresh drop', 'luma-commerce' ) . '</b><span>' . esc_html__( 'Utility layers for everyday motion.', 'luma-commerce' ) . '</span><a href="' . esc_url( luma_commerce_shop_url() ) . '">' . esc_html__( 'Explore', 'luma-commerce' ) . ' ↗</a></div></div></li>';
    foreach ( $departments as $slug => $label ) echo '<li><a href="' . esc_url( luma_commerce_category_url( $slug ) ) . '">' . esc_html( $label ) . '</a></li>';
    echo '<li class="luma-menu-sale"><a href="' . esc_url( home_url( '/sale/' ) ) . '">' . esc_html__( 'Sale', 'luma-commerce' ) . '</a></li>';
    echo '</ul>';
}

function luma_commerce_fallback_footer_menu() {
    echo '<ul class="luma-footer-menu"><li><a href="' . esc_url( luma_commerce_shop_url() ) . '">' . esc_html__( 'Shop all', 'luma-commerce' ) . '</a></li><li><a href="' . esc_url( luma_commerce_category_url( 'new-in' ) ) . '">' . esc_html__( 'New in', 'luma-commerce' ) . '</a></li><li><a href="' . esc_url( home_url( '/sale/' ) ) . '">' . esc_html__( 'Sale', 'luma-commerce' ) . '</a></li></ul>';
}

function luma_commerce_shop_url() {
    if ( function_exists( 'wc_get_page_permalink' ) ) {
        $shop_url = wc_get_page_permalink( 'shop' );
        if ( $shop_url ) return $shop_url;
    }
    return home_url( '/shop/' );
}

function luma_commerce_brand_name() {
    return get_theme_mod( 'luma_brand_name', 'Luma' );
}

function luma_commerce_asset( $path ) {
    return trailingslashit( LUMA_COMMERCE_URI ) . 'assets/' . ltrim( $path, '/' );
}

function luma_commerce_category_url( $slug ) {
    $term = get_term_by( 'slug', sanitize_title( $slug ), 'product_cat' );
    if ( $term && ! is_wp_error( $term ) ) {
        $url = get_term_link( $term );
        if ( ! is_wp_error( $url ) ) return $url;
    }
    return home_url( '/product-category/' . sanitize_title( $slug ) . '/' );
}

function luma_commerce_sanitize_container( $value ) {
    return max( 1080, min( 1800, absint( $value ) ) );
}

function luma_commerce_sanitize_scale( $value ) {
    return max( 0.85, min( 1.15, (float) $value ) );
}

function luma_commerce_sanitize_choice( $value, $choices ) {
    return array_key_exists( $value, $choices ) ? $value : array_key_first( $choices );
}

function luma_commerce_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'luma_branding', array( 'title' => __( 'Luma Branding', 'luma-commerce' ), 'priority' => 30 ) );
    $wp_customize->add_setting( 'luma_brand_name', array( 'default' => 'Luma', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_brand_name', array( 'label' => __( 'Brand name', 'luma-commerce' ), 'section' => 'luma_branding', 'type' => 'text', 'description' => __( 'Used when no custom logo is set.', 'luma-commerce' ) ) );
    $wp_customize->add_setting( 'luma_show_author_credit', array( 'default' => false, 'sanitize_callback' => 'wp_validate_boolean', 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_show_author_credit', array( 'label' => __( 'Show CodeWithDani credit publicly', 'luma-commerce' ), 'section' => 'luma_branding', 'type' => 'checkbox' ) );
    foreach ( array( 'luma_instagram_url' => 'Instagram URL', 'luma_facebook_url' => 'Facebook URL', 'luma_tiktok_url' => 'TikTok URL' ) as $social_setting => $social_label ) { $wp_customize->add_setting( $social_setting, array( 'default' => '', 'sanitize_callback' => 'esc_url_raw', 'transport' => 'refresh' ) ); $wp_customize->add_control( $social_setting, array( 'label' => __( $social_label, 'luma-commerce' ), 'section' => 'luma_branding', 'type' => 'url' ) ); }
    $colors = array( 'luma_accent' => array( '#f0523d', __( 'Signal accent color', 'luma-commerce' ) ), 'luma_paper' => array( '#f5f2ec', __( 'Paper background color', 'luma-commerce' ) ) );
    foreach ( $colors as $setting => $color ) { $wp_customize->add_setting( $setting, array( 'default' => $color[0], 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'refresh' ) ); $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $setting, array( 'label' => $color[1], 'section' => 'luma_branding' ) ) ); }

    $wp_customize->add_section( 'luma_layout', array( 'title' => __( 'Luma Layout & UX', 'luma-commerce' ), 'priority' => 31 ) );
    $wp_customize->add_setting( 'luma_container_width', array( 'default' => 1440, 'sanitize_callback' => 'luma_commerce_sanitize_container', 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_container_width', array( 'label' => __( 'Container width', 'luma-commerce' ), 'section' => 'luma_layout', 'type' => 'number', 'input_attrs' => array( 'min' => 1080, 'max' => 1800, 'step' => 10 ) ) );
    $wp_customize->add_setting( 'luma_radius', array( 'default' => '2px', 'sanitize_callback' => function( $value ) { return luma_commerce_sanitize_choice( $value, array( '0px' => 'Square', '2px' => 'Subtle', '6px' => 'Soft' ) ); }, 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_radius', array( 'label' => __( 'Corner radius', 'luma-commerce' ), 'section' => 'luma_layout', 'type' => 'select', 'choices' => array( '0px' => __( 'Square', 'luma-commerce' ), '2px' => __( 'Subtle', 'luma-commerce' ), '6px' => __( 'Soft', 'luma-commerce' ) ) ) );
    $wp_customize->add_setting( 'luma_button_style', array( 'default' => 'solid', 'sanitize_callback' => function( $value ) { return luma_commerce_sanitize_choice( $value, array( 'solid' => 'Solid', 'outline' => 'Outline' ) ); }, 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_button_style', array( 'label' => __( 'Button style', 'luma-commerce' ), 'section' => 'luma_layout', 'type' => 'select', 'choices' => array( 'solid' => __( 'Solid', 'luma-commerce' ), 'outline' => __( 'Outline', 'luma-commerce' ) ) ) );
    $wp_customize->add_setting( 'luma_sticky_header', array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean', 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_sticky_header', array( 'label' => __( 'Sticky header', 'luma-commerce' ), 'section' => 'luma_layout', 'type' => 'checkbox' ) );
    $wp_customize->add_setting( 'luma_announcement_text', array( 'default' => 'New season, sharper essentials.', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_announcement_text', array( 'label' => __( 'Announcement text', 'luma-commerce' ), 'section' => 'luma_layout', 'type' => 'text' ) );
    $wp_customize->add_setting( 'luma_enable_animations', array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean', 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_enable_animations', array( 'label' => __( 'Enable motion effects', 'luma-commerce' ), 'section' => 'luma_layout', 'type' => 'checkbox' ) );

    $wp_customize->add_section( 'luma_woocommerce', array( 'title' => __( 'Luma WooCommerce', 'luma-commerce' ), 'priority' => 31 ) );
    $wp_customize->add_setting( 'luma_product_columns', array( 'default' => 4, 'sanitize_callback' => function( $value ) { return max( 2, min( 5, absint( $value ) ) ); }, 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_product_columns', array( 'label' => __( 'Product columns', 'luma-commerce' ), 'section' => 'luma_woocommerce', 'type' => 'number', 'input_attrs' => array( 'min' => 2, 'max' => 5, 'step' => 1 ) ) );
    $wp_customize->add_setting( 'luma_products_per_page', array( 'default' => 12, 'sanitize_callback' => function( $value ) { return max( 4, min( 48, absint( $value ) ) ); }, 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_products_per_page', array( 'label' => __( 'Products per page', 'luma-commerce' ), 'section' => 'luma_woocommerce', 'type' => 'number', 'input_attrs' => array( 'min' => 4, 'max' => 48, 'step' => 4 ) ) );
    foreach ( array( 'luma_gallery_zoom' => __( 'Gallery zoom', 'luma-commerce' ), 'luma_gallery_lightbox' => __( 'Gallery lightbox', 'luma-commerce' ), 'luma_gallery_slider' => __( 'Gallery slider', 'luma-commerce' ) ) as $setting => $label ) { $wp_customize->add_setting( $setting, array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean', 'transport' => 'refresh' ) ); $wp_customize->add_control( $setting, array( 'label' => $label, 'section' => 'luma_woocommerce', 'type' => 'checkbox' ) ); }

    $wp_customize->add_section( 'luma_typography', array( 'title' => __( 'Luma Typography', 'luma-commerce' ), 'priority' => 32 ) );
    $heading_choices = array( 'narrow' => 'Arial Narrow, Helvetica Neue, Arial, sans-serif', 'sans' => 'Helvetica Neue, Arial, sans-serif', 'serif' => 'Georgia, serif' );
    $body_choices = array( 'system' => 'Inter, ui-sans-serif, system-ui, sans-serif', 'sans' => 'Helvetica Neue, Arial, sans-serif', 'serif' => 'Georgia, serif' );
    $wp_customize->add_setting( 'luma_heading_font', array( 'default' => 'narrow', 'sanitize_callback' => function( $value ) use ( $heading_choices ) { return luma_commerce_sanitize_choice( $value, $heading_choices ); }, 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_heading_font', array( 'label' => __( 'Heading font', 'luma-commerce' ), 'section' => 'luma_typography', 'type' => 'select', 'choices' => array( 'narrow' => __( 'Condensed sans', 'luma-commerce' ), 'sans' => __( 'Clean sans', 'luma-commerce' ), 'serif' => __( 'Editorial serif', 'luma-commerce' ) ) ) );
    $wp_customize->add_setting( 'luma_body_font', array( 'default' => 'system', 'sanitize_callback' => function( $value ) use ( $body_choices ) { return luma_commerce_sanitize_choice( $value, $body_choices ); }, 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_body_font', array( 'label' => __( 'Body font', 'luma-commerce' ), 'section' => 'luma_typography', 'type' => 'select', 'choices' => array( 'system' => __( 'System sans', 'luma-commerce' ), 'sans' => __( 'Clean sans', 'luma-commerce' ), 'serif' => __( 'Editorial serif', 'luma-commerce' ) ) ) );
    $wp_customize->add_setting( 'luma_heading_scale', array( 'default' => 1, 'sanitize_callback' => 'luma_commerce_sanitize_scale', 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_heading_scale', array( 'label' => __( 'Heading scale', 'luma-commerce' ), 'section' => 'luma_typography', 'type' => 'number', 'input_attrs' => array( 'min' => .85, 'max' => 1.15, 'step' => .05 ) ) );
    $wp_customize->add_setting( 'luma_body_size', array( 'default' => 15, 'sanitize_callback' => function( $value ) { return max( 13, min( 18, absint( $value ) ) ); }, 'transport' => 'refresh' ) );
    $wp_customize->add_control( 'luma_body_size', array( 'label' => __( 'Body size', 'luma-commerce' ), 'section' => 'luma_typography', 'type' => 'number', 'input_attrs' => array( 'min' => 13, 'max' => 18, 'step' => 1 ) ) );
}
add_action( 'customize_register', 'luma_commerce_customize_register' );

function luma_commerce_show_author_credit() {
    return (bool) get_theme_mod( 'luma_show_author_credit', false );
}

function luma_commerce_cart_count() {
    if ( function_exists( 'WC' ) && WC() && isset( WC()->cart ) && is_object( WC()->cart ) ) {
        return (int) WC()->cart->get_cart_contents_count();
    }
    return 0;
}

function luma_commerce_cart_link() {
    $url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' );
    printf(
        '<a class="luma-icon-link luma-bag-link" href="%1$s" aria-label="%2$s"><span class="luma-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M5 8h14l-1 13H6L5 8Z"></path><path d="M9 8V6a3 3 0 0 1 6 0v2"></path></svg></span><span class="luma-icon-label">Bag</span><span class="luma-cart-count">%3$d</span></a>',
        esc_url( $url ),
        esc_attr__( 'View shopping bag', 'luma-commerce' ),
        luma_commerce_cart_count()
    );
}

function luma_commerce_comment( $comment, $args, $depth ) {
    $tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
    ?>
    <<?php echo tag_escape( $tag ); ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( 'luma-comment', $comment ); ?>>
        <article class="luma-comment__body">
            <header class="luma-comment__meta">
                <div class="luma-comment__author"><?php echo get_avatar( $comment, 48 ); ?><strong><?php echo wp_kses_post( get_comment_author_link() ); ?></strong></div>
                <a href="<?php echo esc_url( get_comment_link( $comment ) ); ?>"><time datetime="<?php echo esc_attr( get_comment_time( 'c' ) ); ?>"><?php echo esc_html( get_comment_date() ); ?></time></a>
            </header>
            <?php if ( '0' === (string) $comment->comment_approved ) : ?><p class="luma-comment__moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'luma-commerce' ); ?></p><?php endif; ?>
            <div class="luma-comment__text"><?php comment_text(); ?></div>
            <div class="luma-comment__reply"><?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></div>
        </article>
    <?php
    if ( 'div' !== $args['style'] ) echo '</' . tag_escape( $tag ) . '>';
}

function luma_commerce_comment_reply_link( $link ) {
    return str_replace( 'comment-reply-link', 'comment-reply-link luma-button luma-button--small', $link );
}
add_filter( 'comment_reply_link', 'luma_commerce_comment_reply_link' );
