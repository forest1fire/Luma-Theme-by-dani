<?php
/**
 * The footer.
 *
 * @package LumaCommerce
 */

defined( 'ABSPATH' ) || exit;
?>
<?php if ( ! luma_commerce_elementor_location( 'footer' ) ) : ?>
    <footer class="luma-site-footer">
        <div class="luma-container">
            <div class="luma-footer-grid">
                <div class="luma-footer-brand">
                    <a class="luma-wordmark luma-wordmark--footer" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="luma-wordmark__name"><?php echo esc_html( luma_commerce_brand_name() ); ?><sup>®</sup></span><?php if ( luma_commerce_show_author_credit() ) : ?><span class="luma-wordmark__byline">By CodeWithDani</span><?php endif; ?></a>
                    <p><?php esc_html_e( 'Modern wardrobe pieces with a considered point of view.', 'luma-commerce' ); ?></p>
                    <?php $luma_socials = array( 'luma_instagram_url' => array( 'label' => 'Instagram', 'short' => 'ig' ), 'luma_facebook_url' => array( 'label' => 'Facebook', 'short' => 'fb' ), 'luma_tiktok_url' => array( 'label' => 'TikTok', 'short' => 'tk' ) ); $luma_social_links = array(); foreach ( $luma_socials as $setting => $social ) { $url = esc_url( get_theme_mod( $setting, '' ) ); if ( $url ) $luma_social_links[] = '<a href="' . $url . '" aria-label="' . esc_attr( $social['label'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $social['short'] ) . '</a>'; } if ( $luma_social_links ) : ?><div class="luma-socials"><?php echo implode( '', $luma_social_links ); ?></div><?php endif; ?>
                </div>
                <div><h2><?php esc_html_e( 'Explore', 'luma-commerce' ); ?></h2><?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'fallback_cb' => 'luma_commerce_fallback_footer_menu', 'menu_class' => 'luma-footer-menu' ) ); ?></div>
                <div><h2><?php esc_html_e( 'Need help?', 'luma-commerce' ); ?></h2><ul class="luma-footer-menu"><li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact us</a></li><li><a href="<?php echo esc_url( home_url( '/shipping-returns/' ) ); ?>">Shipping & returns</a></li><li><a href="<?php echo esc_url( home_url( '/size-guide/' ) ); ?>">Size guide</a></li><li><a href="<?php echo esc_url( home_url( '/faqs/' ) ); ?>">FAQs</a></li></ul></div>
                <div class="luma-footer-newsletter"><h2><?php esc_html_e( 'The Luma edit', 'luma-commerce' ); ?></h2><p><?php esc_html_e( 'Sign up for first access to drops, edits, and private offers.', 'luma-commerce' ); ?></p><form class="luma-newsletter-form" action="#" method="post" data-luma-lead><label class="screen-reader-text" for="luma-email">Email address</label><input id="luma-email" type="email" name="email" placeholder="Email address" required><input class="luma-form-trap" type="text" name="luma_website" tabindex="-1" autocomplete="off" aria-hidden="true"><button type="submit" aria-label="Subscribe">↗</button><span class="luma-lead-status" aria-live="polite"></span></form></div>
            </div>
            <?php if ( is_active_sidebar( 'footer-widgets' ) ) : ?><div class="luma-footer-widgets"><?php dynamic_sidebar( 'footer-widgets' ); ?></div><?php endif; ?>
            <div class="luma-footer-bottom"><span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( luma_commerce_brand_name() ); ?></span><span><?php esc_html_e( 'Designed for WooCommerce · Built for Elementor', 'luma-commerce' ); ?></span></div>
        </div>
    </footer>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
