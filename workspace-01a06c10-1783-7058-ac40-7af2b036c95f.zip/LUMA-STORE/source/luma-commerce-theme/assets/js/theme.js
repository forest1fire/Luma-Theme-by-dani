(function () {
    'use strict';

    function safeFocus(element) {
        if (element && typeof element.focus === 'function') element.focus();
    }

    function isMobileLayout() {
        return window.matchMedia && window.matchMedia('(max-width: 1024px)').matches;
    }

    function initShopViewToggle() {
        var toggle = document.querySelector('.luma-shop-view-toggle');
        var products = document.querySelector('.woocommerce ul.products');
        if (!toggle || !products) return;
        var buttons = toggle.querySelectorAll('[data-luma-view]');
        var setView = function (view) {
            var listView = 'list' === view;
            products.classList.toggle('luma-products--list', listView);
            buttons.forEach(function (button) {
                var active = button.getAttribute('data-luma-view') === view;
                button.classList.toggle('is-active', active);
                button.setAttribute('aria-pressed', active ? 'true' : 'false');
            });
            try { localStorage.setItem('lumaShopView', view); } catch (e) {}
        };
        buttons.forEach(function (button) { button.addEventListener('click', function () { setView(button.getAttribute('data-luma-view')); }); });
        var saved = 'grid';
        try { saved = 'list' === localStorage.getItem('lumaShopView') ? 'list' : 'grid'; } catch (e) {}
        setView(saved);
    }

    document.addEventListener('DOMContentLoaded', function () {
        initShopViewToggle();
        var menuButton = document.querySelector('.luma-menu-toggle');
        var nav = document.querySelector('#primary-navigation');
        var searchButton = document.querySelector('.luma-search-toggle');
        var searchPanel = document.querySelector('#luma-search-panel');

        if (menuButton && nav) {
            var menuLabel = menuButton.querySelector('.screen-reader-text');
            var closeMenu = function () {
                nav.classList.remove('is-open');
                menuButton.setAttribute('aria-expanded', 'false');
                document.body.classList.remove('luma-menu-open');
                if (menuLabel) menuLabel.textContent = 'Open menu';
            };
            var openMenu = function () {
                nav.classList.add('is-open');
                menuButton.setAttribute('aria-expanded', 'true');
                document.body.classList.add('luma-menu-open');
                if (menuLabel) menuLabel.textContent = 'Close menu';
                safeFocus(nav.querySelector('a'));
            };
            menuButton.addEventListener('click', function () {
                if (nav.classList.contains('is-open')) closeMenu(); else openMenu();
            });
            nav.addEventListener('click', function (event) {
                if (event.target.closest && event.target.closest('a')) closeMenu();
            });
            document.addEventListener('click', function (event) {
                if (!nav.classList.contains('is-open') || nav.contains(event.target) || menuButton.contains(event.target)) return;
                closeMenu();
            });
            document.addEventListener('keyup', function (event) {
                if ('Escape' === event.key && nav.classList.contains('is-open')) {
                    closeMenu();
                    safeFocus(menuButton);
                }
            });
            window.addEventListener('resize', function () {
                if (!isMobileLayout()) closeMenu();
            });
        }

        if (searchButton && searchPanel) {
            var closeSearch = function () {
                searchPanel.setAttribute('hidden', 'hidden');
                searchButton.setAttribute('aria-expanded', 'false');
            };
            searchButton.addEventListener('click', function () {
                var closed = searchPanel.hasAttribute('hidden');
                if (closed) {
                    searchPanel.removeAttribute('hidden');
                    searchButton.setAttribute('aria-expanded', 'true');
                    safeFocus(searchPanel.querySelector('input'));
                } else {
                    closeSearch();
                    safeFocus(searchButton);
                }
            });
            document.addEventListener('click', function (event) {
                if (searchPanel.hasAttribute('hidden') || searchPanel.contains(event.target) || searchButton.contains(event.target)) return;
                closeSearch();
            });
            document.addEventListener('keyup', function (event) {
                if ('Escape' === event.key && !searchPanel.hasAttribute('hidden')) {
                    closeSearch();
                    safeFocus(searchButton);
                }
            });
        }
    });
}());
