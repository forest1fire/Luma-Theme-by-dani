# Luma Store workspace

Current releases: **Luma Theme 1.32.0** · **Luma Core 1.29.0**

## Where everything is

- `source/luma-commerce-core/` — editable Luma Core WooCommerce plugin source.
- `source/luma-commerce-theme/` — editable Luma WordPress theme source.
- `source/luma-demo-kit/` — editable demo products, Elementor templates and campaign assets.
- `packages/luma-commerce-core.zip` — installable Core plugin.
- `packages/luma-commerce-theme.zip` — installable Luma theme.
- `packages/luma-demo-kit.zip` — demo kit package.
- `docs/LUMA-v1.29.0-FILTER-UX-UPGRADE.md` — latest mobile filter drawer and applied-filter upgrade report.
- `docs/LUMA-v1.32.0-SHOP-UX-UPGRADE.md` — latest Theme shop-view and recovery-page upgrade report.
- `previews/luma-commerce-preview.html` — standalone visual preview.

The root workspace is intentionally kept clean. Canonical images live inside the source packages; duplicate root-level copies and superseded audit reports were removed.
